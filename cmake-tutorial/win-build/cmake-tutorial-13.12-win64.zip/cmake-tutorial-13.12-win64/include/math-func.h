//
// Created by CQSF on 2022/7/22.
//

#ifndef FIRST_TUTORIAL_MATH_FUNC_H
#define FIRST_TUTORIAL_MATH_FUNC_H
extern double mySqrtByStrategy(double);
/**
 * 根据文件读取 ...
 * @return  需要被处理的平方差的被处理数 ...
 */
extern double sqrtByFile(double);
#endif //FIRST_TUTORIAL_MATH_FUNC_H
