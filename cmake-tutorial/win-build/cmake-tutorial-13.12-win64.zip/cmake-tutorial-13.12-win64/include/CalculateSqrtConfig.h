// the configured options and settings for CalculateSqrt，@@引用的变量可以通过CMakeLists.txt来设置
#define CalculateSqrt_VERSION_MAJOR 13
#define CalculateSqrt_VERSION_MINOR 12
#define USE_MATH_FUNC
//目标平台提供了exp和log函数吗?
/* #undef HAVE_LOG */
/* #undef HAVE_EXP */
